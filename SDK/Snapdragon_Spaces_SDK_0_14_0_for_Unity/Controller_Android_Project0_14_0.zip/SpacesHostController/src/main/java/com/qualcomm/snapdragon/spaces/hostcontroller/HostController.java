/******************************************************************************
 * File: HostController.java
 * Copyright (c) 2023 Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
 *
 * Confidential and Proprietary - Qualcomm Technologies, Inc.
 *
 ******************************************************************************/

package com.qualcomm.snapdragon.spaces.hostcontroller;

import android.util.Log;
import com.qualcomm.snapdragon.spaces.hostcontroller.ui.spaces_controller.HostControllerFragment;

public class HostController {
    public static void ResetPose() {
        HostControllerFragment.Companion.ResetPose();
    }
}
